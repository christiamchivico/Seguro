<?php

namespace Illuminate\Contracts\Filesystem;

interface Cloud extends Filesystem
{
    //
}
