<?php

namespace Illuminate\Database\Eloquent;

/**
 * @deprecated since version 5.2. Use Illuminate\Database\Eloquent\Scope.
 */
interface ScopeInterface extends Scope
{
}
