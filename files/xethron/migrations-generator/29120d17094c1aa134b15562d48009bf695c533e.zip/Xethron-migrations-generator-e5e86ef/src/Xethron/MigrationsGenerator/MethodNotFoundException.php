<?php namespace Xethron\MigrationsGenerator;

class MethodNotFoundException extends \Exception {}
